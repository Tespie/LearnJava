import java.util.Arrays;

public class Tryyyyyyyyyyyyyyyy {
   
   public static void main(String[] args) {

//      String sen = "tejas is great !"; // sejatay siay treagay !
//      String sen = "Pig latin is cool"; // igPay atinlay siay oolcay
      String sen = "Pig latin is cool"; // hisTay siay ymay tringsay
      String sarry[] = sen.split(" ");
      
      StringBuilder sb = new StringBuilder();
      
//      for (String s : sarry) {
//         if (!s.equals("!")) {
//            sb.append(s.substring(1)).append(s.charAt(0)).append("ay").append(" ");
//         } else {
//            sb.append(s);
//         }
//      }
   
      for (int i=0;i < sarry.length;i++) {
         if (!sarry[i].equals("!")) {
            if(i!= (sarry.length-1)){
               sb.append(sarry[i].substring(1)).append(sarry[i].charAt(0)).append("ay").append(" ");
            } else {
               sb.append(sarry[i].substring(1)).append(sarry[i].charAt(0)).append("ay");
            }
            
         } else {
            sb.append(sarry[i]);
         }
      }
   
      System.out.println(sb);
      
   }
}
//   igPay atinlay siay oolcay